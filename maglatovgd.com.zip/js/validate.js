"use strict"

document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('form');
    form.addEventListener('submit', formSend);

    async function formSend(e) {
        e.preventDefault();

        let error = formValidate(form);

        let formData = new FormData(form);

        if (error === 0) {
            form.classList.add('sending');
            alert(error);
            let response = await fetch ('sendmail.php', {
                method: 'POST',
                body: formData
            });
            if (response.ok) {
                let result = await response.json();
                alert(result.message);
                form.reset();
                form.classList.remove('sending');
            } else {
                alert("Ошибка. Попробуйте еще раз.");
                form.classList.remove('sending');
            }
        } else {
            alert('Заполните обязательные поля');
        }
        }

    function formValidate(form) {
        let error = 0;
        let formReq = document.querySelectorAll('._req');

        for (let index = 0; index < formReq.length; index++) {
            const input = formReq[index];
            formRemoveError(input);

            if (input.classList.contains('email')) {
                if (emailTest(input)) {
                    formAddError(input);
                    error++;
                    // alert('email');
                }
            } 
            if (input.value == '') {
                formAddError(input);
                error++;
                // alert('input');
            }
        }
        alert(error);
        return error;
    }

    function formAddError(input) {
        // input.parentElement.classList.add('_error');
        input.classList.add('_error');
    }
    function formRemoveError(input) {
        // input.parentElement.classList.remove('_error');
        input.classList.remove('_error');
    }

    // функция теста E-mail
    function emailTest(input) {
        return !/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,8})+$/.test(input.value);
    }



})